// Your OAuth application key and secret. Get them from https://meocloud.pt/my_apps
key    = "xxxxxxxxxxxxxxxxxxxxxxxxxxxx";
secret = "xxxxxxxxxxxxxxxxxxxxxxxxxxxx";

// Values obtained after running login.js
access_token = "xxxxxxxxxxxxxxxxxxxxxx";
token_secret = "xxxxxxxxxxxxxxxxxxxxxx";
